import{f as p,a as l}from"../chunks/D-hE1vav.js";import"../chunks/BkyQyEiz.js";import{s as e,f as c,n as h}from"../chunks/DjjVuYvg.js";import{s as u}from"../chunks/mp63qBuI.js";var d=p(`<h1>Application Maintenance</h1> <p>Using systemd: here's the .service file:</p> <pre></pre> <p>The bash file called by the service file instructs node to execute index.js in the build file.</p> <pre></pre> <p>Edit the application in VS Code and push it to Github. Then, in the server, clone the application and, after updates on the desktop are pushed to Github, run "git pull origin main".</p> <p>WARNING: Don't include the "build" subdirectory in .gitignore. Call "npm run build" on the desktop after revisions, then "git push -u origin main". Then, ssh into the server and call "git pull origin main".</p> <p>Nginx works its reverse-proxy magic on the html files loaded by systemd.</p> <pre></pre> <!> <br/><br/><br/><br/>`,1);function f(o,i){var t=d(),n=e(c(t),4);n.textContent=`[Unit]
Description=blog.service
After=network.target

[Service]
Type=simple
ExecStart=bash /etc/systemd/system/blog.sh
Restart=on-failure
User=u
Group=u

[Install]
WantedBy=multi-user.target
`;var r=e(n,4);r.textContent=`#! /bin/bash
cd /home/u/Apps/newblog
PORT=3007 node build `;var s=e(r,8);s.textContent=`
cat blog.schalk2.com
server {
    server_name blog.schalk2.com;

location / {
    proxy_pass http://localhost:3007;  # Your SvelteKit port
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    
    # Apply the buffer settings here if you prefer
    proxy_buffer_size 128k;
    proxy_buffers 16 64k;
    proxy_busy_buffers_size 128k;
}

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/recursive-closures.schalk2.com/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/recursive-closures.schalk2.com/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
server {
    if ($host = blog.schalk2.com) {
        return 301 https://$host$request_uri;
    } # managed by Certbot

    listen 80;
    server_name blog.schalk2.com;
    return 404; # managed by Certbot
} `;var a=e(s,2);u(a,i,"default",{}),h(5),l(o,t)}export{f as component};
