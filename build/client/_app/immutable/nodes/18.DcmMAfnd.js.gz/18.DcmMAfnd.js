import{f as r,a as i}from"../chunks/CcU3PJm1.js";import"../chunks/C1z_K0OT.js";import{s as o,f as m,c as l,n as t,r as u}from"../chunks/CMBpGD-e.js";var c=r(`<h1>Men and Women -- Attempts to Gain Insight
     Into the Urges, Choices, and Evolutionary Strategies
      Promoting Successful Procreation</h1> <p> <a href="https://en.wikipedia.org/wiki/Homo">Wikipedia</a></p> <br/><br/> <a href="https://www.youtube.com/watch?v=7aMOUA3pPyM">When a Man Loves a Woman</a> <br/><br/> <a href="https://www.youtube.com/watch?v=76TpX4u6HYM">The Brutal Truth About Female Nature That Men Ignore – Schopenhauer</a> <br/><br/> <a href="https://www.quora.com/Why-does-whipping-excite-some-people">Quora</a> <br/><br/> <a href="https://www.youtube.com/results?search_query=+Olivia+Alexa">Olivia Alexa</a> <br/><br/> <a href="https://www.youtube.com/watch?v=tySjJq8l3AQ">Friedrich Hegel\\’s DARK Truth About Men Who Fall in LOVE a lot</a> <br/><br/> <a href="https://www.youtube.com/watch?v=jsBJQ9qY-E0">WOMEN WANT DANGEROUS MEN! Freud's BRUTAL truth!</a> <br/><br/> <a href="https://www.youtube.com/watch?v=CYcLTiV5ylM">Why Intelligent Men Scare Most Women | Kierkegaard</a> <br/><br/> <a href="https://www.youtube.com/watch?v=DzAc502EADs">Schopenhauer Feared this one thing about women more than death.</a> <br/><br/> <p>When a Man Loves a Woman Lyrics</p><pre></pre> <br/><br/> <a href="https://www.google.com/search?q=%22https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D6meW-K-1e7Q&amp;oq=%22https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D6meW-K-1e7Q&amp;gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDMxODhqMGo3qAIIsAIB&amp;sourceid=chrome&amp;ie=UTF-8#fpstate=ive&amp;vld=cid:b1fb7c93,vid:FRlIrhdk4LY,st:0">When a Man Loves a Woman (Original Studio Demo)</a> <a href="https://www.youtube.com/watch?v=45YBJiTJqIg">Women DON'T Want you to Find this Video! - Socrates</a> <a href="https://www.youtube.com/watch?v=TZDPwFw9npI">Carl Jung’s SHOCKING Truth: Most Women Don’t Want Great Men</a> <a href="https://www.youtube.com/watch?v=kYUJu33yd08">How to Stop Hiding – Epictetus Knew the Danger of That Mask</a> <a href=""></a> <a href=""></a> <a href=""></a> <a href=""></a> <a href=""></a> src/routes/Relationships/(99) Philosos - YouTube.html`,1);function b(n){var a=c(),e=o(m(a),2),s=l(e);s.nodeValue="Homo (from Latin homō 'human') is a genus of great ape (family Hominidae) that emerged from the genus Australopithecus and encompasses only a single extant species, Homo sapiens (modern humans), along with a number of extinct species (collectively called archaic humans) classified as either ancestral or closely related to modern humans; these include Homo erectus and Homo neanderthalensis. The oldest member of the genus is Homo habilis, with records of just over 2 million years ago.[a] Homo, together with the genus Paranthropus, is probably most closely related to the species Australopithecus africanus within Australopithecus.[4] The closest living relatives of Homo are of the genus Pan (chimpanzees and bonobos), with the ancestors of Pan and Homo estimated to have diverged around 5.7–11 million years ago during the Late Miocene. --",t(),u(e);var h=o(e,46);h.textContent=`When a man loves a woman
Can't keep his mind on nothin' else
He'd change the world for the good thing he's found
If she is bad, he can't see it
She can do no wrong
Turn his back on his best friend if he put her down

When a man loves a woman
He'll spend his very last dime
Tryin' to hold on to what he needs
He'd give up all his comforts
And sleep out in the rain
If she said that's the way
It ought to be

Well, this man loves you, woman
I gave you everything I had
Tryin' to hold on to your heartless love
Baby, please don't treat me bad

When a man loves a woman
Down deep in his soul
She can bring him such misery
If she is playin' him for a fool
He's the last one to know
Lovin' eyes can never see

When a man loves a woman
He can do her no wrong
He can never want
Some other girl

Yes when a man loves a woman
I know exactly how he feels
Cause baby, baby, you're my world

When a man loves a woman...`,t(22),i(n,a)}export{b as component};
