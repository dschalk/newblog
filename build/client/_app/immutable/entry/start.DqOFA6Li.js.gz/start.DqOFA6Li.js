import{l as o,a as r}from"../chunks/o3dHzVjY.js";export{o as load_css,r as start};
