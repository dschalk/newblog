import{l as o,a as r}from"../chunks/DGPS9G1W.js";export{o as load_css,r as start};
