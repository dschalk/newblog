import{l as o,a as r}from"../chunks/D74bvgoe.js";export{o as load_css,r as start};
