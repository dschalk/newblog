import{e}from"./CMBpGD-e.js";e();
